package com.example.ureka02.user.enums;

public enum Role {
	ADMIN,
	USER
}
