package com.example.ureka02.user.enums;

public enum AuthProvider {
	LOCAL,
	KAKAO
}
