package com.example.ureka02.payment.controller;

import com.example.ureka02.payment.dto.TossConfirmRequest;
import com.example.ureka02.payment.entity.Payment;
import com.example.ureka02.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/payment")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    // 결제 정보 조회 (프론트용)
    @GetMapping("/api/{orderId}")
    @ResponseBody
    public ResponseEntity<?> getPayment(@PathVariable String orderId) {
        Payment payment = paymentService.getPaymentByKey(orderId);

        return ResponseEntity.ok(Map.of(
                "amount", payment.getAmount(),
                "status", payment.getStatus()
        ));
    }

    // Toss 결제 승인 콜백
    @PostMapping("/api/confirm")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> confirmPayment(
            @RequestBody TossConfirmRequest request) {

        paymentService.confirmSuccess(request.getPaymentKey());

        Payment payment = paymentService.getPaymentByKey(request.getPaymentKey());

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("status", payment.getStatus());

        return ResponseEntity.ok(response);
    }
}
