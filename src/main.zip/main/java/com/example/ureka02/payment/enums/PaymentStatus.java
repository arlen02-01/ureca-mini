package com.example.ureka02.payment.enums;

public enum PaymentStatus {
    REQUESTED, SUCCESS, FAILED
}
