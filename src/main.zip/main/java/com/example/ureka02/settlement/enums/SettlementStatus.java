package com.example.ureka02.settlement.enums;

public enum SettlementStatus {
    READY, IN_PROGRESS, COMPLETED
}

