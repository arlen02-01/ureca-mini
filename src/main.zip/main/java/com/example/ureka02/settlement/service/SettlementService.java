package com.example.ureka02.settlement.service;

import com.example.ureka02.payment.entity.Payment;
import com.example.ureka02.payment.enums.PaymentStatus;
import com.example.ureka02.payment.repository.PaymentRepository;
import com.example.ureka02.recruitment.entity.RecruitmentMember;
import com.example.ureka02.recruitment.repository.RecruitMemberRepository;
import com.example.ureka02.settlement.entity.Settlement;
import com.example.ureka02.settlement.enums.SettlementStatus;
import com.example.ureka02.settlement.repository.SettlementRepository;
import com.example.ureka02.user.User;
import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class SettlementService {

    private final SettlementRepository settlementRepository;
    private final RecruitMemberRepository recruitMemberRepository;
    private final PaymentRepository paymentRepository;

    public Settlement createSettlement(RecruitmentMember admin, Long totalAmount) {

        // 1️⃣ Settlement 새로 생성 (❗ 필드 사용 금지)
        Settlement settlement = Settlement.builder()
                .recruitment(admin.getRecruitment())
                .creator(admin.getMember())
                .status(SettlementStatus.IN_PROGRESS)
                .totalAmount(totalAmount)
                .build();

        settlementRepository.save(settlement);

        // 2️⃣ 정산 참여자 조회
        List<RecruitmentMember> members =
                recruitMemberRepository.findByRecruitmentId(
                        admin.getRecruitment().getId()
                );

        int memberCount = members.size();

        // 3️⃣ 개인별 금액 계산
        long amountPerPerson = totalAmount / memberCount;

        // 4️⃣ Payment 생성
        for (RecruitmentMember member : members) {
            Payment payment = Payment.create(
                    member.getMember(),
                    settlement,
                    amountPerPerson
            );
            paymentRepository.save(payment);
        }

        return settlement;
    }

    /**
     * 모든 Payment가 SUCCESS면 Settlement를 COMPLETE로 변경
     */
    @Transactional
    public void checkAndComplete(Long settlementId) {

        Settlement settlement = settlementRepository.findById(settlementId)
                .orElseThrow(() -> new IllegalArgumentException("정산 없음"));

        // 이미 완료된 경우 스킵
        if (settlement.getStatus() == SettlementStatus.COMPLETED) {
            return;
        }

        List<Payment> payments =
                paymentRepository.findBySettlementId(settlementId);

        boolean allSuccess = payments.stream()
                .allMatch(p -> p.getStatus() == PaymentStatus.SUCCESS);

        if (allSuccess) {
            settlementRepository.save(
                    Settlement.builder()
                            .recruitment(settlement.getRecruitment())
                            .creator(settlement.getCreator())
                            .status(SettlementStatus.COMPLETED)
                            .totalAmount(settlement.getTotalAmount())
                            .build()
            );
        }
    }

}
