package com.example.ureka02.recruitment.Enum;

public enum RecruitMemberRole {
    ADMIN, // 정산 관리자(모집자)
    MEMBER
}
