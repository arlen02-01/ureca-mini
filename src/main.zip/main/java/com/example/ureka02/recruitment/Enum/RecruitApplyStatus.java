package com.example.ureka02.recruitment.Enum;

public enum RecruitApplyStatus {
    APPLIED, // 신청 완료
    CANCELED, // 신청 취소
    REJECTED // 마감으로 인한 거절
}
