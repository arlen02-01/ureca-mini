package com.example.ureka02.friends.domain;

public enum FriendStatus {
    PENDING, ACCEPTED
}
