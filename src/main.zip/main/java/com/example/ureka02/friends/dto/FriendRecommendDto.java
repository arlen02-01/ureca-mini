package com.example.ureka02.friends.dto;

public record FriendRecommendDto(Long userId, String userName, int commonCount) {}